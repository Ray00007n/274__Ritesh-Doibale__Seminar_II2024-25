<!DOCTYPE html>
<html>
<head>
    <title>Digital Clock</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #000;
            color: #0f0;
            text-align: center;
            font-size: 48px;
            margin-top: 20%;
        }
    </style>
</head>
<body>

<?php
// Get the current server time
date_default_timezone_set('UTC'); // Change to your timezone if needed
$serverTime = date("H:i:s");
?>

<div id="clock"><?php echo $serverTime; ?></div>

<script>
    function updateClock() {
        const clock = document.getElementById('clock');
        let time = new Date();
        clock.innerHTML = time.toLocaleTimeString();
    }

    setInterval(updateClock, 1000);
</script>

</body>
</html>
