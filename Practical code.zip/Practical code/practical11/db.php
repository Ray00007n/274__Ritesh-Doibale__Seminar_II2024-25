<?php
$con = mysqli_connect("localhost", "root", "", "student");
if (!isset($con)) {
    echo "Error:" . mysqli_error($con);
}
?>