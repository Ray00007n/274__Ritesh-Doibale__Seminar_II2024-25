<?php
$file="content.txt";

if(!file_exists($file)){
    file_put_contents($file,0);
}
$visitors=file_get_contents($file);
$visitors++;
file_put_contents($file,$visitors);

echo"<h1><b>Visitors</b>:".$visitors."</h1>";
?>