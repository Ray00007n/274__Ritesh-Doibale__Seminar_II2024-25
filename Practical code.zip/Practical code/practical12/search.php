<?php
include("db.php");

if($_SERVER["REQUEST_METHOD"]=="POST"){
    if($_POST["order"]=="ascending"){
    $query= "SELECT * FROM student  ORDER by rollno ASC";}
    else{
        $query = "SELECT * FROM student  ORDER by rollno DESC";
    }
}
   $result= mysqli_query($con,$query);


   echo "<table  border='1' cellpadding='5'>
        <tr>
            <th>Roll no</th>
            <th>Name</th>
            <th>class</th>
            <th>PRN no</th>
        </tr>";
    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
            <td>" . $row['rollno'] . "</td>
             <td>" . $row['name'] . "</td>
            <td>" . $row['class'] . "</td>
            <td>" . $row['prnno'] . "</td>
            </tr>
            ";        }
    } else {
        echo "0 results";
    }

    
    
    echo"</table>";

mysqli_close($con);
?>
